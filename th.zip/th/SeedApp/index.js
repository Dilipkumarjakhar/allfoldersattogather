let dilip=document.getElementById('dilip')
let arr=['pea'];
let imgs=['./images/toma.jpeg','./images/pexels-photo-768090.webp']
for(var i=0;i<21;i++){
  let div1=document.createElement('div');
  div1.setAttribute('class','col')
  let div2=document.createElement('div');
  div2.setAttribute('class','card');
  let img=document.createElement('img');
  img.setAttribute('class','card-img-top');
    img.src=imgs[i];
  let div3=document.createElement('div');
  div3.setAttribute('class','card-body');
  let h5=document.createElement('h5');
  h5.setAttribute('class','card-title')
  h5.innerText=arr[i];
  let btn=document.createElement('button');
  btn.setAttribute('class','btn btn-primary');
  let a=document.createElement('a');
  a.href='See More'
  a.innerText="See More"
//   btn.innerHTML="See More";
btn.append(a)
  let p=document.createElement('p');
  p.setAttribute('class','card-text')
//   p.innerHTML="This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."
  div3.append(h5,btn,p);
  div2.append(img,div3)
  
  div1.append(div2);
  dilip.append(div1);
}