

import './form.css'
import {useState} from "react";




const initial={
  gamename:"",
  gameauthor:"",
  gameprice:"", 
  gametags:"",
  gamedesc:"",
  forkids:"",
  gamerating:""
}

export const Form=()=> {
const [forms,setforms]=useState(initial);

    const url="http://localhost:3001/games";





const handelChange=(e)=>{
 const dilip = e.target.name;
    if (dilip === "forkids") {
      e.target.value = e.target.checked;
    }
    setforms({
      ...forms,
      [dilip]: e.target.value,
    });
}



function submit(e){

e.preventDefault();
const data={ 
  gamename:forms.gamename,
  gameauthor:forms.gameauthor,
    gameprice:forms.gameprice,
    gametags:forms.gametags,
    gamedesc:forms.gamedesc,
    forkids:forms.forkids,
    gamerating:forms.gamerating 
  };
  fetch(url,{
  method: "POST",
  body: JSON.stringify(data),
  // body: JSON.stringify(forms),
      headers: {
        "content-type":"application/json",
      },
    }
    
    ).then(forms)
  
   };




  return (
    
  <div className="App">
<h1>Game App</h1>

  <form id="addgame" onSubmit={(e)=>{
       submit(e);
      //  Reset();
       document.getElementById("addgame").reset();
  }} >

  gamename :
  <input 

onChange={handelChange} 
  type="text" name="gamename" value={forms.gamename} id="gamename"/>




gameauthor:
 <input 

onChange={handelChange} 
type="text" name="gameauthor" id="gameauthor" value={forms.gameauthor}/>



gameprice:
 <input 

 onChange={handelChange}  
  type="text" name="gameprice" id="gameprice" value={forms.gameprice}/>




  gametags:
   <input 

   onChange={handelChange} 
  type="text" name="gametags" id="gametags"  value={forms.gametags}/>


gamedesc:
<textarea 
  onChange={handelChange} 
  type="text" name="gamedesc" id="gamedesc" value={forms.gamedesc}></textarea>

  forkids:
<input
onChange={handelChange} 
  type="checkbox" name="forkids" id="forkids" value={forms.forkids} />


  Ratting:
   <select 

   onChange={handelChange} 
   name="gamerating" value={forms.gamerating} id="gamerating">
     <option value="1">1</option>
     <option value="2">2</option>
     <option value="3">3</option>
     <option value="4">4</option>
     <option value="5">5</option>
   </select>

   <input type="submit" />

  </form>
 </div>
)

    }
