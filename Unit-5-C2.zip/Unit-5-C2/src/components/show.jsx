
import React from 'react';
import './form.css'
import {useEffect,useState} from 'react'


export const Show=()=>{

const [data,setdata]=useState([]);
const [ndata,setndata]=useState([]);

    useEffect(()=>{
        getData()
      },[])

      function sortr(){

          data.sort((a, b)=>{
              let r= a.gameprice>b.gameprice;
              setndata(r)
            }); 
        }

        function gamename(){
            data.sort(function (x, y) {
                let r= x.gamename - y.gamename;
                setndata(r);
            });
            
            }

      const getData=()=>{
      
        fetch('http://localhost:3001/games')
       
        .then((d)=> d.json())
          .then((res)=>{
              setdata(res);
                //   console.log(res)
                })
                gamename();
      }

   

    return(

    <div>
       <table border="0" cellspacing="15" cell="5">
          <thead>
          <tr>
              <td>gamename</td>
              <td>gameauthor</td>
              <td>gametags</td>
              <td><button onClick={()=>{
                  let s= data.sort((a, b) => {
                    return a.gameprice - b.gameprice;
                  })}}>gameprice</button></td>

              <td><button
               onClick={sortr}
               >
               ratting</button></td>
              
              <td>Kids</td>
              
          </tr>

          </thead>
              <tbody>
         {
             data.map((item)=>{
             return(

              <tr className="gamerow">
                 <th className="gamename">{item.gamename}</th>
                 <th className="gameauthor">{item.gameauthor}</th>
                  <th>{item.gametags}</th>
                  <th className="gameprice">{item.gameprice}</th>
                  <th className="gamerating">{item.gamerating}</th>
                  <th>{item.forkids}</th>  
              </tr>
             )
                })}
              

              </tbody>

       </table>

       <div>
      
       </div>



        </div>
    )
}
