import {Form} from './components/form';
import {Show} from './components/show';


function App() {
  return(
<div className='App'>

<h1>Hello</h1>
<Form />
<Show />

</div>


  )

}

export default App;
