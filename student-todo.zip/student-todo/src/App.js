//import { Todo } from "./components/Todo";
import { useEffect, useState } from "react";
import { v4 as uuid } from "uuid";
import "./App.css";

function App() {

const [ftitle,setftitle]=useState("");
const [stitle,setstitle]=useState("");
const [loading ,setloading]=useState(false);

const [able,setable]=useState(true);

const [page,setpage]=useState(0);

const [ftodo,setftodo]=useState([]);

useEffect(()=>{
  getdata()
},[page])

// console.log(ftodo);

const getdata=()=>{
  setloading(true);
  fetch(`http://localhost:3001/dilip?_page=${page}&_limit=3`)
  .then((d)=> d.json())
    .then((response)=>{
      setftodo(response);
      setloading(false);
    })
}

// const deleteIt=(id)=>{
//   let newlist = ftodo.filter((item) => item.id !== id);
//   setftodo(newlist);
// }


  return  loading ?"Loading..." :( 
   
 
    <div className="main">
    <div className="smain">
    <h1 className="title">Todo...</h1>
   
      <input 
   
      className="inputTitle"
      placeholder="Add Title..."
      type="text"
       onChange={(e)=>{
        console.log('e:', e.target.value)
                setftitle(e.target.value);
      }}/>
      <input 
     
      className="inputBody" 
      placeholder="Add Task..."
      type='text'
        onChange={(e)=>{
          console.log('e:', e.target.value)

          setstitle(e.target.value)
        }}
      />
      <button className="addBtn" 
      onClick={()=>{
        // setftodo([...ftodo,{status:"false",Addtitle:ftitle,Addtask:stitle}])
        const data={status:"false",Addtitle:ftitle,Addtask:stitle,id:uuid()}
        fetch('http://localhost:3001/dilip',{
          method:"POST",
          body:JSON.stringify(data),
          headers:{
            'Content-Type': 'application/json'
            }
        }).then(getdata)


      }}>Add</button>
      
      <div className="container">

      <div className="todoitem">
               
           <span style={{display:"inline"}}> 
           {ftodo.map((e)=>{
               return (
                 

                 <h1 className="userData">{e.Addtitle}-{e.Addtask} 
                 {/* <span className="btn"> */}

                 <button className="btn"
                  // onClick={()=>{deleteIt}}
                  >Done</button>
                 {/* </span>  */}
                 </h1>
                 
               
                 ) 
            
            })}</span>
         
  </div>
  
     </div>   
    </div>
    <button className="prev" onClick={()=>{
      setpage(page-1);
    }}
    disabled={able}>Prev</button>

    <button className="next" onClick={()=>{
      setpage(page+1);
      setable(false);
    }}>Next</button>
    </div>
  );
}

export default App;
