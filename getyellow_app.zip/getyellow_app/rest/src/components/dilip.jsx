import React from 'react';
import { useState } from 'react';
import './balloon.css';
export const Balloon = () => {
    let go=[
         {Ist:'1',color:'red'},
         {Ist:'2',color:'pink'},
         {Ist:'3',color:'black'},
         {Ist:'4',color:'green'},
         {Ist:'5',color:'yellow'},
    ]
    // go.map((item)=>{
    //     console.log(item.Ist,item.color)
    // })
let [number,setnumber] =useState();
let [dis,setdis] =useState('none');
   
let [circles,setcircles] = useState([
        'black','green','blue','yellow','orange'
    ])

    let [leftcircles,setleftcircles] = useState([])
    let [shootButton,setshootButton]=useState(true);
   let [data,setdata]=useState([]);
 


   
   let shoot=()=>{

    go.map((ele)=>{
        if(number==ele.Ist){
            console.log("number",number)
            leftcircles=[...leftcircles,ele]
            setleftcircles(leftcircles);
            setdis('flex');
        }

    })
   console.log('left',leftcircles)
        
    }
let back =(i)=>{
console.log(i)

}
  return (
   
    <div className="main_div">
       <div className="left">
           <div className="empty_div">
               <h3>Empty div</h3>
           </div>
           <div className="fill_div">
           {leftcircles.map((ele,i)=>{
               console.log(ele.color)
               console.log(ele.Ist)
               ele=ele.color;
               i=ele.Ist;
               
               return (
                   <div key={i} 
                   onClick={()=>alert(i)}
                   className="box_circle"
                   style={{background:ele,display:dis}}
                   >{i}</div>
               );
           })}
           </div>

       </div>
        <div className="right">
             <div className="circle_styles">
             {/* {circles.map((item,id)=>{
               return (
                   <div key={id}
                   className="circle_div"
                   style={{background:item}}
                   ></div>
               );
            })} */}
             {go.map((item,id)=>{
               return (
                   <div key={id}
                   className="circle_div"
                   style={{background:item.color}}
                   ></div>
               );
            })}
             </div>
             <div className="input_button">
                 <input type="number" onChange={(e)=>{
                     setnumber(e.target.value)
                    if(e.target.value>=1 && e.target.value<=5){

                    setshootButton(false)
                    }else{
                    setshootButton(true)

                    } 
                        console.log(e.target.value)
                 }}/>
                 <button onClick={shoot}
                 disabled={shootButton}>shoot
                 </button>
                
             </div>
        </div>
    

   
    </div>
   
  )
}
