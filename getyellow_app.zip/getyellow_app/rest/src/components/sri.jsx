import React,{useState} from 'react'

export  const Sri = () => {
    const [right,setRight]=useState(
        [{id:1,value:"!",col:'red'},
        {id:2,value:"@",col:"yellow"},
        {id:3,value:"#",col:'black'}])
    const [left,setLeft]=useState([])
    return (
      <div className="App">
        <div className="empty-div">
          Empty Box
        {left.map((item)=>{
            return <div onClick={()=>{
              let updatedLeft=left.filter((e)=>{
                return e.id!==item.id
              })
              updatedLeft.sort((a,b)=>{
                return a.id-b.id;
              })
            setLeft(updatedLeft)
            const newArr=[...right,item]
            newArr.sort((a,b)=>{
              return a.id-b.id;
            })
            setRight(newArr)
            }}   key={item.id} >{item.value}</div>
          })
    
          
          }
          
        </div>
        <hr />
        Fill BOx
       <div className="color-boxes">
          {right.map((item)=>{
            return <div
             key={item.id}
             style={{background:item.col}}
             >{item.value}</div>
          })}
       </div>
       <hr />
       <form onSubmit={(e)=>{
         e.preventDefault();
         let num=e.target.number.value;
         let [removedItem]=right.filter((item)=>{
           return item.id==num;
         })
         const updatedRight=right.filter((item)=>item.id!==removedItem.id)
         updatedRight.sort((a,b)=>{
          return a.id-b.id;
        })
         setRight(updatedRight)
         setLeft([...left,removedItem])
         
       }}>
         <input name='number' type="number" />
         <input type="submit" />
       </form>
  
  
  
  
      </div>
    )
  }



