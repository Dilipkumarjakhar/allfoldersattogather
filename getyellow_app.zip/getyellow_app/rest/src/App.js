// import MyComponent from './components/map'
import {Balloon} from './components/Balloon';
// import {Sri} from './components/sri'
import './App.css';

function App() {
  return (
    <div className="App">
  
     
<Balloon/>
{/* <Sri/> */}
    </div>
  );
}

export default App;
