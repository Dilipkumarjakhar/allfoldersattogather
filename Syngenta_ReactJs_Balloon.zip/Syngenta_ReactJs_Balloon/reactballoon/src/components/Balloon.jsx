import React from 'react'
import { useState,useEffect } from 'react';
import './Balloon.css'
export const Balloon = () => {

    let [inputvalue,setinputValue]=useState();
    let [prev,setprev]=useState();

    // useEffect(()=>{
    //     generateColor();
    // },[])
    // let generateColor =()=> {
       
    //     right.map((el,i)=>{
    //         console.log(el.col,i)
    //         // let x='#' +  Math.random().toString(16).substr(-6)
    //         el.col=color[i]
    //     })
        
    //     console.log(right);
    //   }
    const [right,setRight]=useState(
      [
  {id:1,value:"1",color:`rgb(${Math.random()*255>>0},${Math.random()*255>>0},${Math.random()*255>>0})`},
  {id:2,value:"2",color:`rgb(${Math.random()*255>>0},${Math.random()*255>>0},${Math.random()*255>>0})`},
  {id:3,value:"3",color:`rgb(${Math.random()*255>>0},${Math.random()*255>>0},${Math.random()*255>>0})`},
  {id:4,value:"4",color:`rgb(${Math.random()*255>>0},${Math.random()*255>>0},${Math.random()*255>>0})`},
  {id:5,value:"5",color:`rgb(${Math.random()*255>>0},${Math.random()*255>>0},${Math.random()*255>>0})`},
    ])
    const [left,setLeft]=useState([])

let [display,setdisplay] =useState('none');
let [shootButton,setshootButton]=useState(true);



  







   return( 
   
   <div className="main_div">
    {/* --------------left div box start-------------  */}
       <div className="left">
           <div className="empty_div">
               <h3>Empty div</h3>
           </div>
           <div className="fill_div">
           {left.map((item)=>{
            return <div
            className="box_circle"
                   style={{background:item.color,display:display}}
             onClick={()=>{
              let updatedLeft=left.filter((e)=>{
                return e.id!==item.id
              })
              updatedLeft.sort((a,b)=>{
                return a.id-b.id;
              })
            setLeft(updatedLeft)
            const newArr=[...right,item]
            newArr.sort((a,b)=>{
              return a.id-b.id;
            })
            setRight(newArr)
            }}   key={item.id} >{item.value}</div>
          })
    
          
          }
           
           </div>
    {/* --------------left div box end-------------  */}

       </div>
    {/* --------------right div box start-------------  */}
        <div className="right">
             <div className="circle_styles">
             {right.map((item)=>{
              
            return <div class='circle_div'
             key={item.id}
             style={{background:item.color}}
            
             >{item.value}</div>
          })}
            
             
             </div>
             <p className="userinputvalues">
             {inputvalue<=0 || inputvalue>5?
                    <div>You Enter {inputvalue} 
                    <br />
                    Please Enter a  Number Range between 1 to 5</div>
                    :null
                       
                        }
             </p>


             <div className="input_button">


             <form 
              onSubmit={(e)=>{
         e.preventDefault();
         let num=e.target.number.value;
       
         let [removedItem]=right.filter((item)=>{
           return item.id==num;
         })
         const updatedRight=right.filter((item)=>item.id!==removedItem.id)
         setdisplay('flex')
         updatedRight.sort((a,b)=>{
          return a.id-b.id;
        })
         setRight(updatedRight)
         setLeft([...left,removedItem])
         
       }}
             >
           <input name='number' type="number" id='input'
               onChange={
             (e)=>{
             if(e.target.value>=1 && e.target.value<=5){
              setshootButton(false)
              setinputValue(e.target.value)
              setprev(e.target.value)
            }else{
              setshootButton(true)
              setinputValue(e.target.value)
           
              }
             }
         }

           />
           <input type="submit" value='shoot'
            disabled={shootButton} 
            id='btn'

            />
          </form>
          </div>
        </div>
    {/* --------------right div box end-------------  */}
    

   
    </div>
   //here is main div box end
  )
}
