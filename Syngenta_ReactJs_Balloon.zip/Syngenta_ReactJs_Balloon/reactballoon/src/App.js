
import './App.css';

import {Balloon} from './components/Balloon';
function App() {
  return (
    <div className="App">
      
      <Balloon/>
    </div>
  );
}

export default App;
