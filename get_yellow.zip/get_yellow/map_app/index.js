var map = new MapmyIndia.Map('map', {center: [28.62, 77.09], zoom: 15, search: false});
          
/*Place Picker plugin initialization*/
 var options={
      map:map,
      callback:callback_method,
     
//     location:{lat:28.8787,lng:77.08888}, //to open that location on map on initailization
//     hyperLocal:true, //Default is false. Location parameter is mandatory to use this parameter.
//     closeBtn:true,
// geolocation:false,
//     closeBtn_callback:closeBtn_callback,
//     search:true,
//     topText:'Location Search',
//     pinImage:'pin.png', //custom pin image
//     pinHeight:40,
// pod:'City',
//     tokenizeAddress:true,
//     filter:'cop:9QGXAM',
//     distance:true,

  };
  var picker= new MapmyIndia.placePicker(options);
  function callback_method(data) {
      let dt=JSON.stringify(data);
     
            console.log(JSON.parse(dt))
           let go=JSON.parse(dt)
           console.log('go:', go)
      alert([
          "Address-"+go.formatted_address+'\n'+
"City-"+go.city+"\n"+
"state-"+go.state+'\n'+
"street-"+go.street+'\n'+
"dist-"+go.street_dist+'\n'+
"subDistrict-"+go.subDistrict+'\n'

      ])
      }   
  






















// mapboxgl.accessToken =
//   "pk.eyJ1IjoiamFraGFyZGlsaXAiLCJhIjoiY2wzZmt0dXY0MDBmOTNjcXd0Znpmdm9rNiJ9.tV0TMGXLJsjStaT-GEv_Yg"

// navigator.geolocation.getCurrentPosition(successLocation, errorLocation, {
//   enableHighAccuracy: true
// })

// function successLocation(position) {
//   setupMap([position.coords.longitude, position.coords.latitude])
// }

// function errorLocation() {
//   setupMap([-2.24, 53.48])
// }

// function setupMap(center) {
//   const map = new mapboxgl.Map({
//     container: "map",
//     style: "mapbox://styles/mapbox/streets-v11",
//     center: center,
//     zoom: 15
//   })

//   const nav = new mapboxgl.NavigationControl()
//   map.addControl(nav)

//   var directions = new MapboxDirections({
//     accessToken: mapboxgl.accessToken
//   })

//   map.addControl(directions, "top-left")
// }
