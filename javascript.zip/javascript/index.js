


    // 1. way to print in javascript
    //console.log("hello word");
    //alert("today income goes to repurcesh ");
   //document.write("this is document write")
   // 2. javascript console API

   // console.log("hello word",4+6,"ANOTHER");
    //console.warn("this is warning");
// console.error("this is error");


// 3. javascript variables
// what are variables? : containe to store the data value
// var number1 = 60;
// var number2 = 35;
//console.log(number1 + number2);

// 4.data types in js
//i.nu8mber
var num1 = 110;
var num2 = 20;

// ii.strings
var str1 = "my name is dilip";
var str2 = 'cse';

//iii.objects
var marks = {
    dilip:99,
    aman:98,
    raj:97,
    bl:99.99
} 
console.log(marks);

// Boolens
var a = true;
var b = false;
console.log(a, b);