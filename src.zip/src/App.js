import { Adddata } from "./components/Adddata";
import { ShowData } from "./components/ShowData";

function App() {
  return (
    <div>
        <h1>Hello world</h1>
      <Adddata />
      <ShowData />
    </div>
  );
}

export default App;
